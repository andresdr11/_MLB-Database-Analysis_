create function hypertable_size(hypertable regclass) returns bigint
    strict
    language plpgsql
as
$$
DECLARE
  num_bytes BIGINT;
BEGIN
   SELECT sum(hd.total_bytes) INTO STRICT num_bytes
   FROM hypertable_detailed_size(hypertable) hd;
   RETURN num_bytes;
END;
$$;

alter function hypertable_size(regclass) owner to postgres;

